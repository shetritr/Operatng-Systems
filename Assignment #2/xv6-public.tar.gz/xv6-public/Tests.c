#include "user.h"

int finish;
int numOfProcess;
int num = 1;

void exectesthandler(int pid, int value){
	printf(1, "test fail: after exec() defult handler%d\n",value,pid);
	finish = 0;
}

void changeHandlerhandler(int pid, int value){
    printf(1, "test succeed : signal handler change in process %d\n",getpid());
    finish = 0;
}

void changeHandlerhandlerbed(int pid, int value){
    printf(1, "test fail : signal handler not change in process %d\n",getpid());
}

void sendsigtesthandler(int pid, int value){
	finish = 0;
	if( value ==  getpid() ){
	  printf(1, "test succeed: got value: %d and its equal to getpid() value: %d\n",value,getpid());
	  return;
	}
       
	printf(1, "test fail: got value: %d and its not equal to getpid() value: %d\n",value,getpid());
	return;
}

void sendsigProchandler(int pid, int value){
  //pid should be the right one
	int mypid = getpid();
	finish = 0;
	if( value == mypid ){
	  printf(1, "test succeed: got value: %d  from %d and its equal to getpid() value: %d \n",value,pid,mypid);
	  return;
	}
       
	printf(1, "test fail: got value: %d and its not equal to getpid() value: %d \n",value,mypid);
	return;
}

void inittest(){
	int pid;
	int i;
	for (i = 0; i < numOfProcess; i++){
	  pid = fork();
	  if (pid == 0) { // child
	     sleep(50);
	     exit(num);
	   } else { // father
             sigsend(pid,getpid());
	     wait(&num);
           }
	}
        return;
}

void sendsigtest(){
	sigset((sig_handler)&sendsigtesthandler);
    int pid;
	int i;
	for (i = 0; i < numOfProcess; i++){
	  finish=1;
        pid= fork();
	  if (pid == 0) { // child code
          while(finish){
             sleep(50);
         }

          exit(num);
	   } else { // father code
          sleep(16);
          sigsend(pid, pid);
          wait(&num);
           }
	}// end of for
        return;
}

void exectest(){
	sigset((sig_handler)&exectesthandler);
	int pid = fork();
	char *argv[2];
	argv[0] = "echo";
        argv[1] = "test passed: exec() set defult handler";
	if(pid==0){
        exec("echo",argv);
    } else {
	    sleep(100);
		sigsend(pid, 0);// dont work because exec change signal handler
	  wait(&num);
	}
	return;
}

void sendsigProc(){
	sigset((sig_handler)&sendsigProchandler);
	int processtable[10];
	int i;
	for (i = 0; i < numOfProcess; i++){
	  finish=1;
	  processtable[i] = fork();
	  if (processtable[i] == 0) { // child code
             if(i>0){
	       sigsend(processtable[i-1], processtable[i-1]);
	     }else {
                 sigsend(processtable[i], processtable[i]);

             }
	     while(finish){
	     	sleep(20);
             }
	     exit(num);
	   }
	}// end of for
	for (i = 0; i < numOfProcess-1; i++)
	  wait(&num);
        return;
}


void changeHandler(){
    sigset((sig_handler)&changeHandlerhandlerbed);
    int i;
    for (i = 0; i < numOfProcess; i++){
        finish=1;
        int pid = fork();
        if (pid == 0) { // child code
            sigset((sig_handler)&changeHandlerhandler);
            while(finish){
                sleep(20);
            }
            exit(num);
        }else {
            sleep(29);
            sigsend(pid, 0);
            wait(&num);
        }
    }
    return;

}



int main(int argc, char *argv[]) {
	if(argc != 2){
          printf(1, "error argc is :%d instead of 2\n",argc);
	  exit(num);
	}
        numOfProcess = atoi(argv[1]);

	    printf(1, "\n");
        printf(1, "init test: create %d process without sigset ,defult handler\n",numOfProcess);
        printf(1, "\n");

        inittest();
//

        printf(1, "\n");
        printf(1, "test send signals : create %d process with fork() and call sigsend \n",numOfProcess);
        printf(1, "\n");

        sendsigtest();

        printf(1, "\n");
        printf(1, "test exec: create process and then use exec()\n",numOfProcess);
        printf(1, "\n");

        exectest();

        printf(1, "\n");
        printf(1, "test proc to proc: create %d process with fork(), send from process to process\n",numOfProcess);
        printf(1, "\n");

        sendsigProc();


        printf(1, "\n");
        printf(1, "test change handler: create %d process with fork(), change the signal handler\n",numOfProcess);
        printf(1, "\n");

        changeHandler();


    printf(1, "test finished\n");
	exit(num);
	
}
