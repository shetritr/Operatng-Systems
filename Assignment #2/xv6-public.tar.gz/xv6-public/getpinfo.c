//
// Created by shetritr on 13/11/18.
//
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc , char *argv[]){
    getpinfo();
    exit(0);
}
